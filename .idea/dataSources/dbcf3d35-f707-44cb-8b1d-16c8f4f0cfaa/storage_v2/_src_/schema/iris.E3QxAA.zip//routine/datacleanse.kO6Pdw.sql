create procedure dataCleanse()
  data_cleanse:BEGIN

DECLARE preUpdateMissingAndWrongHandset INT(4) DEFAULT 0;
DECLARE missingAndWrongHandsetUpdated INT(4) DEFAULT 0;
DECLARE postUpdateMissingAndWrongHandset INT(4) DEFAULT 0;
DECLARE authLocationZeroCount INT(4) DEFAULT 0;
DECLARE preUpdateGetAuthLocationFromHandset INT(4) DEFAULT 0;
DECLARE getAuthLocationFromHandsetUpdated INT(4) DEFAULT 0;
DECLARE postUpdateGetAuthLocationFromHandset INT(4) DEFAULT 0;
DECLARE preUpdateGetAuthLocationFromMovedHandset INT(4) DEFAULT 0;
DECLARE getAuthLocationFromMovedHandsetUpdated INT(4) DEFAULT 0;
DECLARE postUpdateGetAuthLocationFromMovedHandset INT(4) DEFAULT 0;
DECLARE authLocationZeroWithHandsetInDifferentAuthGoupCount INT(4) DEFAULT 0;
DECLARE preUpdateGetAuthLocationFromAuthGroupsWithSingleAuthLocation INT(4) DEFAULT 0;
DECLARE getAuthLocationFromAuthGroupsWithSingleAuthLocationUpdated INT(4) DEFAULT 0;
DECLARE postUpdateGetAuthLocationFromAuthGroupsWithSingleAuthLocation INT(4) DEFAULT 0;
DECLARE authLocationZeroWithScanFromMirroredAuthLocationCount INT(4) DEFAULT 0;
DECLARE preUpdateGetAuthLocationFromHandsetWithSingleAuthLocationTransactions INT(4) DEFAULT 0;
DECLARE getAuthLocationFromHandsetWithSingleAuthLocationTransactionsUpdated INT(4) DEFAULT 0;
DECLARE postUpdateGetAuthLocationFromHandsetWithSingleAuthLocationTransactions INT(4) DEFAULT 0;
DECLARE authLocationZeroCountAtEnd INT(4) DEFAULT 0;

SET @procID = UNIX_TIMESTAMP();


INSERT INTO iris.DataCleanse_Log (LogTimestamp, LogAction)
VALUES (@procID, 'Start');



SELECT COUNT(tp.id_transaction_present) INTO preUpdateMissingAndWrongHandset
FROM iris.TRANSACTION_present tp 
WHERE tp.id_handset IN (1, 0)
OR tp.id_handset IS NULL
AND tp.test = 0
AND tp.duplicate = 0
AND tp.verified_on IS NOT NULL;

UPDATE iris.TRANSACTION_present tp 
LEFT JOIN iris.HANDSET h USING (imei)
SET tp.id_handset = h.id_handset
WHERE tp.id_handset IN (0, 1)
OR tp.id_handset IS NULL
AND h.id_handset IS NOT NULL
AND tp.test = 0
AND tp.duplicate = 0
AND tp.verified_on IS NOT NULL;

SELECT ROW_COUNT() INTO missingAndWrongHandsetUpdated;

SELECT COUNT(tp.id_transaction_present) INTO postUpdateMissingAndWrongHandset
FROM iris.TRANSACTION_present tp 
WHERE tp.id_handset IN (1, 0)
OR tp.id_handset IS NULL
AND tp.test = 0
AND tp.duplicate = 0
AND tp.verified_on IS NOT NULL;

INSERT INTO iris.DataCleanse_Log (LogTimestamp, LogAction, PreUpdateRecords, RecordsUpdated, PostUpdateRecords)
VALUES (@procID, 'TP get H from imei Update', preUpdateMissingAndWrongHandset, missingAndWrongHandsetUpdated, postUpdateMissingAndWrongHandset);

SELECT COUNT(tp.id_transaction_present) INTO authLocationZeroCount
FROM iris.TRANSACTION_present tp 
WHERE tp.id_auth_location IN (1, 0)
AND tp.test = 0
AND tp.duplicate = 0
AND tp.verified_on IS NOT NULL;

INSERT INTO iris.DataCleanse_Log (LogTimestamp, LogAction, PreUpdateRecords)
VALUES (@procID, 'TP AL0 Count', authLocationZeroCount);


IF authLocationZeroCount = 0 THEN
	INSERT INTO iris.DataCleanse_Log (LogTimestamp, LogAction)
	VALUES (@procID, 'End');

	LEAVE data_cleanse;
END IF;

SELECT COUNT(tp.id_transaction_present) INTO preUpdateGetAuthLocationFromHandset
FROM iris.TRANSACTION_present tp 
LEFT JOIN iris.HANDSET h USING (id_handset)
LEFT JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
LEFT JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
WHERE tp.id_auth_location IN (1, 0)
AND tp.test = 0
AND tp.duplicate = 0
AND tp.id_handset <> 0
AND tp.verified_on IS NOT NULL
AND h.id_auth_location NOT IN (1, 0)
AND h.last_register_on <= tp.date_redeemed
AND ag.type = 'retailer'
AND tp.id_auth_group = ag2.id_auth_group;

UPDATE iris.TRANSACTION_present tp
JOIN iris.HANDSET h ON tp.id_handset = h.id_handset
JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
SET tp.id_auth_location = h.id_auth_location
WHERE tp.id_auth_location IN (1, 0)
AND tp.test = 0
AND tp.duplicate = 0
AND tp.id_handset <> 0
AND tp.verified_on IS NOT NULL
AND h.id_auth_location NOT IN (1, 0)
AND h.last_register_on <= tp.date_redeemed
AND ag.type = 'retailer'
AND tp.id_auth_group = ag2.id_auth_group;

SELECT ROW_COUNT() INTO getAuthLocationFromHandsetUpdated;

SELECT COUNT(tp.id_transaction_present) INTO postUpdateGetAuthLocationFromHandset
FROM iris.TRANSACTION_present tp 
LEFT JOIN iris.HANDSET h USING (id_handset)
LEFT JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
LEFT JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
WHERE tp.id_auth_location IN (1, 0)
AND tp.test = 0
AND tp.duplicate = 0
AND tp.verified_on IS NOT NULL
AND tp.id_handset <> 0
AND h.id_auth_location NOT IN (1, 0)
AND h.last_register_on <= tp.date_redeemed
AND ag.type = 'retailer'
AND tp.id_auth_group = ag2.id_auth_group;

INSERT INTO iris.DataCleanse_Log (LogTimestamp, LogAction, PreUpdateRecords, RecordsUpdated, PostUpdateRecords)
VALUES (@procID, 'TP get AL from H in same AG and date range', preUpdateGetAuthLocationFromHandset, getAuthLocationFromHandsetUpdated, postUpdateGetAuthLocationFromHandset);

SELECT COUNT(tp.id_transaction_present) INTO preUpdateGetAuthLocationFromMovedHandset
FROM iris.TRANSACTION_present tp 
LEFT JOIN iris.HANDSET h USING (id_handset)
LEFT JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
LEFT JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
WHERE tp.id_auth_location IN (1, 0)
AND tp.test = 0
AND tp.duplicate = 0
AND tp.verified_on IS NOT NULL
AND tp.id_handset <> 0
AND h.id_auth_location NOT IN (1, 0)
AND h.last_register_on > tp.date_redeemed
AND ag.type = 'retailer'
AND tp.id_auth_group = ag2.id_auth_group;

UPDATE iris.TRANSACTION_present tp
LEFT JOIN iris.HANDSET h USING (id_handset)
LEFT JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
LEFT JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
SET tp.id_auth_location = h.id_auth_location
WHERE tp.id_auth_location IN (1, 0)
AND tp.test = 0
AND tp.duplicate = 0
AND tp.verified_on IS NOT NULL
AND tp.id_handset <> 0
AND h.id_auth_location NOT IN (1, 0)
AND h.last_register_on > tp.date_redeemed
AND ag.type = 'retailer'
AND tp.id_auth_group = ag2.id_auth_group;

SELECT ROW_COUNT() INTO getAuthLocationFromMovedHandsetUpdated;

SELECT COUNT(tp.id_transaction_present) INTO postUpdateGetAuthLocationFromMovedHandset
FROM iris.TRANSACTION_present tp 
LEFT JOIN iris.HANDSET h USING (id_handset)
LEFT JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
LEFT JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
WHERE tp.id_auth_location IN (1, 0)
AND tp.test = 0
AND tp.duplicate = 0
AND tp.verified_on IS NOT NULL
AND tp.id_handset <> 0
AND h.id_auth_location NOT IN (1, 0)
AND h.last_register_on > tp.date_redeemed
AND ag.type = 'retailer'
AND tp.id_auth_group = ag2.id_auth_group;

INSERT INTO iris.DataCleanse_Log (LogTimestamp, LogAction, PreUpdateRecords, RecordsUpdated, PostUpdateRecords)
VALUES (@procID, 'TP get AL from H in same AG but has moved', preUpdateGetAuthLocationFromMovedHandset, getAuthLocationFromMovedHandsetUpdated, postUpdateGetAuthLocationFromMovedHandset);

SELECT COUNT(tp.id_transaction_present) INTO authLocationZeroWithHandsetInDifferentAuthGoupCount
FROM iris.TRANSACTION_present tp 
LEFT JOIN iris.HANDSET h USING (id_handset)
LEFT JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
LEFT JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
WHERE tp.id_auth_location IN (1, 0)
AND tp.test = 0
AND tp.duplicate = 0
AND tp.verified_on IS NOT NULL
AND tp.id_handset <> 0
AND h.id_auth_location NOT IN (1, 0)
AND h.last_register_on > tp.date_redeemed
AND ag.type = 'retailer'
AND tp.id_auth_group <> ag2.id_auth_group;

INSERT INTO iris.DataCleanse_Log (LogTimestamp, LogAction, PreUpdateRecords)
VALUES (@procID, 'TP AL0 H Moved AG Count', authLocationZeroWithHandsetInDifferentAuthGoupCount);

IF authLocationZeroWithHandsetInDifferentAuthGoupCount > 0 THEN

	SELECT count(tp.id_transaction_present) INTO preUpdateGetAuthLocationFromAuthGroupsWithSingleAuthLocation
	FROM iris.TRANSACTION_present tp
	INNER JOIN (
		
		SELECT id_parent, id_auth_location, count(id_auth_location) as group_auth_location_count
		FROM iris.AUTH_group
		INNER JOIN (
			
			SELECT DISTINCT tp.id_auth_group
			FROM iris.TRANSACTION_present tp 
			LEFT JOIN iris.HANDSET h USING (id_handset)
			LEFT JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
			LEFT JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
			WHERE tp.id_auth_location IN (1, 0)
			AND tp.test = 0
			AND tp.duplicate = 0
			AND tp.verified_on IS NOT NULL
			AND tp.id_handset <> 0
			AND h.id_auth_location NOT IN (1, 0)
			AND h.last_register_on > tp.date_redeemed
			AND ag.type = 'retailer'
			AND tp.id_auth_group <> ag2.id_auth_group) as AGs_with_one_AL ON AGs_with_one_AL.id_auth_group = id_parent
		WHERE type = 'retailer'
		GROUP by id_parent
		HAVING count(id_auth_location) = 1) as single_groups ON single_groups.id_parent = tp.id_auth_group
	LEFT JOIN iris.HANDSET h USING (id_handset)
	LEFT JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
	LEFT JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
	WHERE tp.id_auth_location IN (1, 0)
	AND tp.test = 0
	AND tp.duplicate = 0
	AND tp.verified_on IS NOT NULL
	AND tp.id_handset <> 0
	AND h.id_auth_location NOT IN (1, 0)
	AND h.last_register_on > tp.date_redeemed
	AND ag.type = 'retailer'
	AND tp.id_auth_group <> ag2.id_auth_group;

	IF preUpdateGetAuthLocationFromAuthGroupsWithSingleAuthLocation > 0 THEN
		UPDATE iris.TRANSACTION_present tp
		INNER JOIN (
			SELECT id_parent, id_auth_location, count(id_auth_location) as group_auth_location_count
			FROM iris.AUTH_group
			INNER JOIN (
				SELECT DISTINCT tp.id_auth_group
				FROM iris.TRANSACTION_present tp 
				LEFT JOIN iris.HANDSET h USING (id_handset)
				LEFT JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
				LEFT JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
				WHERE tp.id_auth_location IN (1, 0)
				AND tp.test = 0
				AND tp.duplicate = 0
				AND tp.verified_on IS NOT NULL
				AND tp.id_handset <> 0
				AND h.id_auth_location NOT IN (1, 0)
				AND h.last_register_on > tp.date_redeemed
				AND ag.type = 'retailer'
				AND tp.id_auth_group <> ag2.id_auth_group) as AGs_with_one_AL ON AGs_with_one_AL.id_auth_group = id_parent
			WHERE type = 'retailer'
			GROUP by id_parent
			HAVING count(id_auth_location) = 1) as single_groups ON single_groups.id_parent = tp.id_auth_group
		LEFT JOIN iris.HANDSET h USING (id_handset)
		LEFT JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
		LEFT JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
		SET tp.id_auth_location = single_groups.id_auth_location
		WHERE tp.id_auth_location IN (1, 0)
		AND tp.test = 0
		AND tp.duplicate = 0
		AND tp.verified_on IS NOT NULL
		AND tp.id_handset <> 0
		AND h.id_auth_location NOT IN (1, 0)
		AND h.last_register_on > tp.date_redeemed
		AND ag.type = 'retailer'
		AND tp.id_auth_group <> ag2.id_auth_group;

		SELECT ROW_COUNT() INTO getAuthLocationFromAuthGroupsWithSingleAuthLocationUpdated;

		SELECT count(tp.id_transaction_present) INTO postUpdateGetAuthLocationFromAuthGroupsWithSingleAuthLocation
		FROM iris.TRANSACTION_present tp
		INNER JOIN (
			
			SELECT id_parent, id_auth_location, count(id_auth_location) as group_auth_location_count
			FROM iris.AUTH_group
			INNER JOIN (
				
				SELECT DISTINCT tp.id_auth_group
				FROM iris.TRANSACTION_present tp 
				LEFT JOIN iris.HANDSET h USING (id_handset)
				LEFT JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
				LEFT JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
				WHERE tp.id_auth_location IN (1, 0)
				AND tp.test = 0
				AND tp.duplicate = 0
				AND tp.verified_on IS NOT NULL
				AND tp.id_handset <> 0
				AND h.id_auth_location NOT IN (1, 0)
				AND h.last_register_on > tp.date_redeemed
				AND ag.type = 'retailer'
				AND tp.id_auth_group <> ag2.id_auth_group) as AGs_with_one_AL ON AGs_with_one_AL.id_auth_group = id_parent
			WHERE type = 'retailer'
			GROUP by id_parent
			HAVING count(id_auth_location) = 1) as single_groups ON single_groups.id_parent = tp.id_auth_group
		LEFT JOIN iris.HANDSET h USING (id_handset)
		LEFT JOIN iris.AUTH_group ag ON h.id_auth_location = ag.id_auth_location
		LEFT JOIN iris.AUTH_group ag2 ON ag.id_parent = ag2.id_auth_group
		WHERE tp.id_auth_location IN (1, 0)
		AND tp.test = 0
		AND tp.duplicate = 0
		AND tp.verified_on IS NOT NULL
		AND tp.id_handset <> 0
		AND h.id_auth_location NOT IN (1, 0)
		AND h.last_register_on > tp.date_redeemed
		AND ag.type = 'retailer'
		AND tp.id_auth_group <> ag2.id_auth_group;
	END IF;

	INSERT INTO iris.DataCleanse_Log (LogTimestamp, LogAction, PreUpdateRecords, RecordsUpdated, PostUpdateRecords)
	VALUES (@procID, 'TP get AL from H which has moved AG but has only 1 AL', preUpdateGetAuthLocationFromAuthGroupsWithSingleAuthLocation, getAuthLocationFromAuthGroupsWithSingleAuthLocationUpdated, postUpdateGetAuthLocationFromAuthGroupsWithSingleAuthLocation);


END IF;

SELECT SUM(transaction_count) INTO preUpdateGetAuthLocationFromHandsetWithSingleAuthLocationTransactions
FROM(
	
	SELECT DISTINCT tp.id_handset, COUNT(tp.id_transaction_present) as transaction_count, handsets.id_auth_location
	FROM iris.TRANSACTION_present tp 
	INNER JOIN 
		(
			
			SELECT tp.id_handset, tp.id_auth_location
			FROM iris.TRANSACTION_present tp 
			WHERE tp.id_auth_location NOT IN (1, 0)
			group by tp.id_handset
			HAVING COUNT(distinct id_auth_location) = 1
		) as handsets on tp.id_handset = handsets.id_handset
	WHERE tp.id_auth_location IN (1, 0)
	AND tp.test = 0
	AND tp.duplicate = 0
	AND tp.verified_on IS NOT NULL
	group by tp.id_handset
) AS summary;

IF preUpdateGetAuthLocationFromHandsetWithSingleAuthLocationTransactions > 0 THEN

	UPDATE iris.TRANSACTION_present tp 
	INNER JOIN 
		(
			SELECT tp.id_handset, tp.id_auth_location
			FROM iris.TRANSACTION_present tp 
			WHERE tp.id_auth_location NOT IN (1, 0)
			GROUP BY tp.id_handset
			HAVING COUNT(DISTINCT id_auth_location) = 1
		) AS handsets ON tp.id_handset = handsets.id_handset
	SET tp.id_auth_location = handsets.id_auth_location
	WHERE tp.id_auth_location IN (1, 0)
	AND tp.test = 0
	AND tp.duplicate = 0
	AND tp.verified_on IS NOT NULL;

	SELECT ROW_COUNT() INTO getAuthLocationFromHandsetWithSingleAuthLocationTransactionsUpdated;

	SELECT SUM(transaction_count) INTO postUpdateGetAuthLocationFromHandsetWithSingleAuthLocationTransactions
	FROM(
		
		SELECT DISTINCT tp.id_handset, COUNT(tp.id_transaction_present) as transaction_count, handsets.id_auth_location
		FROM iris.TRANSACTION_present tp 
		INNER JOIN 
			(
				
				SELECT tp.id_handset, tp.id_auth_location
				FROM iris.TRANSACTION_present tp 
				WHERE tp.id_auth_location NOT IN (1, 0)
				group by tp.id_handset
				HAVING COUNT(distinct id_auth_location) = 1
			) as handsets on tp.id_handset = handsets.id_handset
		WHERE tp.id_auth_location IN (1, 0)
		AND tp.test = 0
		AND tp.duplicate = 0
		AND tp.verified_on IS NOT NULL
		group by tp.id_handset
	) AS summary;

	INSERT INTO iris.DataCleanse_Log (LogTimestamp, LogAction, PreUpdateRecords, RecordsUpdated, PostUpdateRecords)
	VALUES (@procID, 'TP get AL from H which has only scanned for one AL', preUpdateGetAuthLocationFromHandsetWithSingleAuthLocationTransactions, getAuthLocationFromHandsetWithSingleAuthLocationTransactionsUpdated, postUpdateGetAuthLocationFromHandsetWithSingleAuthLocationTransactions);
END IF;


SELECT COUNT(tp.id_transaction_present) INTO authLocationZeroCountAtEnd
FROM iris.TRANSACTION_present tp 
WHERE tp.id_auth_location IN (1, 0)
AND tp.test = 0
AND tp.duplicate = 0
AND tp.verified_on IS NOT NULL;

INSERT INTO iris.DataCleanse_Log (LogTimestamp, LogAction, PreUpdateRecords)
VALUES (@procID, 'Final TP AL0 Count', authLocationZeroCountAtEnd);


INSERT INTO iris.DataCleanse_Log (LogTimestamp, LogAction)
VALUES (@procID, 'Finish');

END;

