create trigger remove_customer_action_tier_history
  before DELETE
  on CONSUMER_ACTION
  for each row
  DELETE FROM customer_action_tier_history
WHERE customer_action_id = OLD.id;

