create trigger HANDSET_after_insert
  after INSERT
  on HANDSET
  for each row
  BEGIN

                                IF NEW.deleted_on IS NOT NULL THEN
                                    SET @changeType = 'DELETE';
                                ELSE
                                    SET @changeType = 'INSERT';
                                END IF;

                                INSERT INTO iris.HANDSET_audit (
                                    audit_action,
                                    audit_on,
                                    id_handset,
                                    id_auth_location,
                                    imei,
                                    label,
                                    type,
                                    app_version,
                                    launcher_version,
                                    test,
                                    net_name,
                                    sim_number,
                                    update_on,
                                    first_register_on,
                                    last_register_on,
                                    last_reset_on,
                                    deleted_on,
                                    device_notification_id)
                                VALUES (
                                    @changeType,
                                    UNIX_TIMESTAMP(),
                                    NEW.id_handset,
                                    NEW.id_auth_location,
                                    NEW.imei,
                                    NEW.label,
                                    NEW.type,
                                    NEW.app_version,
                                    NEW.launcher_version,
                                    NEW.test,
                                    NEW.net_name,
                                    NEW.sim_number,
                                    NEW.update_on,
                                    NEW.first_register_on,
                                    NEW.last_register_on,
                                    NEW.last_reset_on,
                                    NEW.deleted_on,
                                    NEW.device_notification_id
                                );

                        END;

