create trigger assign_registration_points_before_update
  before UPDATE
  on CONSUMER_ACTION
  for each row
  begin
if NEW.id_action in (24416,21693) && OLD.id_consumer != NEW.id_consumer then 
	
	
	
    
    
    if NEW.id_action = 24416 AND now() between '2018-02-10' and '2018-02-27'
		then 
			insert into persistent_points_event (customer_action_id, points, type, awarded_on) 
				select  NEW.id, 88, 'registration points', now() from 
				CONSUMER c where c.id_consumer = NEW.id_consumer and
                not exists (select 1 from persistent_points_event where customer_action_id = NEW.id 
                and `type` = 'registration points');
	elseif NEW.id_action = 21693
		then 
			insert into persistent_points_event (customer_action_id, points, type, awarded_on) 
				select  NEW.id, 50, 'registration points', now() from 
				CONSUMER c where c.id_consumer = NEW.id_consumer and
                not exists (select 1 from persistent_points_event where customer_action_id = NEW.id 
                and `type` = 'registration points');
    end if;
end if;
end;

