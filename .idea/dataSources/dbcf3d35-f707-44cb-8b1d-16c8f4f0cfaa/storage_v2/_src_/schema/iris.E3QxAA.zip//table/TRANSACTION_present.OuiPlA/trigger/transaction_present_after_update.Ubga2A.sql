create trigger transaction_present_after_update
  after UPDATE
  on TRANSACTION_present
  for each row
  begin
IF NEW.test = 1 AND OLD.test = 0 THEN
    insert into test_transaction (transaction_present_id) values (NEW.id_transaction_present);
END IF;
end;

