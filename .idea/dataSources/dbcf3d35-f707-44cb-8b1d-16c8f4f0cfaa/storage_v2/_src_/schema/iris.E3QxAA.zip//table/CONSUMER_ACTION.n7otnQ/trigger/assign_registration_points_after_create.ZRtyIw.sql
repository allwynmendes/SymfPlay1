create trigger assign_registration_points_after_create
  after INSERT
  on CONSUMER_ACTION
  for each row
  begin
if NEW.id_action in (24416,21693) then 
	if NEW.id_action = 24416 AND NEW.created_on between '2018-02-10' and '2018-02-27'
		then 
			insert into persistent_points_event (customer_action_id, points, type, awarded_on) 
				select  NEW.id, 88, 'registration points', NEW.created_on from 
				signup s join signup_definition sd on sd.id = s.signup_definition_id 
                where customer_id = NEW.id_consumer and registration_action_id = NEW.id_action 
                and not exists (select 1 from persistent_points_event where customer_action_id = NEW.id 
                and `type` = 'registration points') group by 1,2,3 having min(signed_up_on) is not null;
	elseif NEW.id_action = 21693
		then 
			insert into persistent_points_event (customer_action_id, points, type, awarded_on) 
				select  NEW.id, 50, 'registration points', NEW.created_on from 
				signup s join signup_definition sd on sd.id = s.signup_definition_id 
                where registration_action_id = NEW.id_action and 
                customer_id = NEW.id_consumer and 
                not exists (select 1 from persistent_points_event where customer_action_id = NEW.id 
                and `type` = 'registration points') group by 1,2,3 having min(signed_up_on) is not null;
    end if;
end if;
end;

