create trigger move_customer_action_tier_row
  after DELETE
  on customer_action_tier
  for each row
  INSERT INTO `customer_action_tier_history`
(`original_id`,
`customer_action_id`,
`tier_id`,
`assigned_on`,
`assignment_method`,
`expired_on`,
`expiry_method`)
VALUES
(OLD.id,
OLD.customer_action_id,
OLD.tier_id,
OLD.assigned_on, 
OLD.assignment_method,
unix_timestamp(now()),
'manual');

