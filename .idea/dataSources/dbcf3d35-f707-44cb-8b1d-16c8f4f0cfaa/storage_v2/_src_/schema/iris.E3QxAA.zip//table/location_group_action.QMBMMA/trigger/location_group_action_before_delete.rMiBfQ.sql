create trigger location_group_action_before_delete
  before DELETE
  on location_group_action
  for each row
  insert into location_group_action_history (location_group_id, id_action, created_on) 
            values (OLD.location_group_id, OLD.id_action, OLD.created_on);

