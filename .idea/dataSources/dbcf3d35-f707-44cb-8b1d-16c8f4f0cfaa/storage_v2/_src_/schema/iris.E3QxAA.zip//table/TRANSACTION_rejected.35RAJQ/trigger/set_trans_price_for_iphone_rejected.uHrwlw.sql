create trigger set_trans_price_for_iphone_rejected
  before INSERT
  on TRANSACTION_rejected
  for each row
  begin
if (NEW.via = 'IPHONE' and NEW.price_source = '') then
    set NEW.price_source = 'atv_account';
    set NEW.price = (select average_transaction_value from AUTH_group join ACTION using (id_auth_group) where id_action = NEW.id_action);
end if;
end;

