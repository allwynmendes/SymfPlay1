create trigger HANDSET_after_update
  after UPDATE
  on HANDSET
  for each row
  BEGIN

                                IF NEW.deleted_on IS NOT NULL AND (OLD.deleted_on <> NEW.deleted_on) THEN
                                    SET @changeType = 'DELETE';
                                ELSE
                                    SET @changeType = 'UPDATE';
                                END IF;

                                IF COALESCE(OLD.id_auth_location, '') <> COALESCE(NEW.id_auth_location, '') OR
                                    COALESCE(OLD.imei, '') <> COALESCE(NEW.imei, '') OR
                                    COALESCE(OLD.label, '') <> COALESCE(NEW.label, '') OR
                                    COALESCE(OLD.type, '') <> COALESCE(NEW.type, '') OR
                                    COALESCE(OLD.app_version, '') <> COALESCE(NEW.app_version, '') OR
                                    COALESCE(OLD.launcher_version, '') <> COALESCE(NEW.launcher_version, '') OR
                                    COALESCE(OLD.test, '') <> COALESCE(NEW.test, '') OR
                                    COALESCE(OLD.net_name, '') <> COALESCE(NEW.net_name, '') OR
                                    COALESCE(OLD.sim_number, '') <> COALESCE(NEW.sim_number, '') OR
                                    COALESCE(OLD.update_on, '') <> COALESCE(NEW.update_on, '') OR
                                    COALESCE(OLD.first_register_on, '') <> COALESCE(NEW.first_register_on, '') OR
                                    COALESCE(OLD.last_register_on, '') <> COALESCE(NEW.last_register_on, '') OR
                                    COALESCE(OLD.last_reset_on, '') <> COALESCE(NEW.last_reset_on, '') OR
                                    COALESCE(OLD.deleted_on, '') <> COALESCE(NEW.deleted_on, '') OR
                                    COALESCE(OLD.device_notification_id, '') <> COALESCE(NEW.device_notification_id, '')
                                THEN
                                    INSERT INTO iris.HANDSET_audit (
                                        audit_action,
                                        audit_on,
                                        id_handset,
                                        id_auth_location,
                                        imei,
                                        label,
                                        type,
                                        app_version,
                                        launcher_version,
                                        test,
                                        net_name,
                                        sim_number,
                                        update_on,
                                        first_register_on,
                                        last_register_on,
                                        last_reset_on,
                                        deleted_on,
                                        device_notification_id)
                                    VALUES (
                                        @changeType,
                                        UNIX_TIMESTAMP(),
                                        NEW.id_handset,
                                        NEW.id_auth_location,
                                        NEW.imei,
                                        NEW.label,
                                        NEW.type,
                                        NEW.app_version,
                                        NEW.launcher_version,
                                        NEW.test,
                                        NEW.net_name,
                                        NEW.sim_number,
                                        NEW.update_on,
                                        NEW.first_register_on,
                                        NEW.last_register_on,
                                        NEW.last_reset_on,
                                        NEW.deleted_on,
                                        NEW.device_notification_id
                                    );
                                END IF;

                        END;

