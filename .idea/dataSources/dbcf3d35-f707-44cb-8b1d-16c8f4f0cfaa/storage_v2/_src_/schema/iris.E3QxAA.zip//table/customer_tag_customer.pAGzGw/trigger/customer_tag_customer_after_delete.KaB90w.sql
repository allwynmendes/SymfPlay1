create trigger customer_tag_customer_after_delete
  after DELETE
  on customer_tag_customer
  for each row
  begin
set @cascade_customer_tag_update = false;
update customer_tag set updated_on = now() where id=OLD.customer_tag_id;
set @cascade_customer_tag_update = null;
end;

