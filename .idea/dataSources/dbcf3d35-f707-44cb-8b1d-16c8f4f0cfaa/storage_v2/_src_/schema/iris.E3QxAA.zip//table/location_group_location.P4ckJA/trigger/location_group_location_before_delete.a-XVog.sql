create trigger location_group_location_before_delete
  before DELETE
  on location_group_location
  for each row
  insert into location_group_location_history (location_group_id, id_auth_location, created_on) values (OLD.location_group_id, OLD.id_auth_location, OLD.created_on);

