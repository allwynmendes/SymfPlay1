create procedure chomp_my_tag()
  begin
declare _small_tag int default 8679;
declare _comm_id int default 34632;
declare _big_tag int default 8678;


DELETE FROM customer_tag_customer 
WHERE
    customer_tag_id = _small_tag;

insert into customer_tag_customer (customer_tag_id, customer_id)
select _small_tag, customer_id FROM
    customer_tag_customer ctc  JOIN
    CONSUMER c on  (id_consumer= customer_id)
WHERE
    customer_tag_id=_big_tag AND email IS NOT NULL and email != '' and allow_email =1 and is_email_blocked =0 
    and deleted_on =0 and email REGEXP '^[^@]+@[^@.]+\.[^@]{2,}$'
and not exists 
(select 1 from FF_COMMUNICATION_log fcl join ff_communication_instance fci on fci.id = fcl.communication_instance_id 
where id_communication =_comm_id and fcl.id_consumer = c.id_consumer ) 
order by ctc.customer_id limit 280;

end;

