create trigger application_version_after_insert
  after INSERT
  on application_version
  for each row
  BEGIN

                                INSERT INTO iris.application_version_audit (
                                    audit_on,
                                    version_id,
                                    application_id,
                                    version_label,
                                    version_key,
                                    is_trusted,
                                    trusted_from,
                                    build_path,
                                    archive)
                                VALUES (
                                    UNIX_TIMESTAMP(),
                                    NEW.id,
                                    NEW.application_id,
                                    NEW.version_label,
                                    NEW.version_key,
                                    NEW.is_trusted,
                                    NEW.trusted_from,
                                    NEW.build_path,
                                    NEW.archive);

                        END;

