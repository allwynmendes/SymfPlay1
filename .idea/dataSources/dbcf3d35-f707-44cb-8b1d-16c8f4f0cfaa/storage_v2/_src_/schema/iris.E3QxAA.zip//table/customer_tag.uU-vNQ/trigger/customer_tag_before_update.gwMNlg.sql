create trigger customer_tag_before_update
  before UPDATE
  on customer_tag
  for each row
  if (@cascade_customer_tag_update is not false) then  
set NEW.updated_on = now();
end if;

