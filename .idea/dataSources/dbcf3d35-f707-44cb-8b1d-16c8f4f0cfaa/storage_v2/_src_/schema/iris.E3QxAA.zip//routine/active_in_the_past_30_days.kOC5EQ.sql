create procedure active_in_the_past_30_days(IN `_date_start` date, IN `_no_of_days` int, IN `_account_id` int)
  begin
declare active_members int;
declare _date_to_search date;
declare _30_days_ago date;
declare _counter int default 0;

create temporary table if not exists temporary_tables.active_in_the_past_30_days( a_date date, account_id int, active_members int) engine = innodb;

truncate table temporary_tables.active_in_the_past_30_days;

while _counter < _no_of_days do

set _date_to_search = date_add(_date_start, interval _counter DAY);
set _30_days_ago = date_add(_date_to_search, interval -30 day); 

SELECT 
    COUNT(*) into active_members
FROM
    (SELECT 
        id_consumer
    FROM
        TRANSACTION_present
    JOIN signup ON customer_id = id_consumer
    WHERE
        id_auth_group = _account_id
            AND date_redeemed BETWEEN UNIX_TIMESTAMP(_30_days_ago) AND UNIX_TIMESTAMP(_date_to_search)
    GROUP BY id_consumer
    HAVING MIN(signed_up_on) < _30_days_ago) t1;

insert into temporary_tables.active_in_the_past_30_days values (_date_to_search, _account_id, active_members);
set _counter = _counter + 1;

end while;


select * from temporary_tables.active_in_the_past_30_days;


end;

