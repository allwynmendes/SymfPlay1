create trigger location_audit_tidy_after_update
  after UPDATE
  on AUTH_location
  for each row
  begin

if (NEW.external_id <> OLD.external_id or OLD.external_id is not null or NEW.external_id is not null)
then
insert into location_audit (location_id, old_external_id, new_external_id)
    values (NEW.id_auth_location, OLD.external_id, NEW.external_id);
end if;

if (NEW.deleted_on > 0)
    then 
UPDATE CONSUMER
        JOIN
    location_group lg ON (preferred_location_group_id = id
        AND type = 'machine')
        JOIN
    location_group_location lgl ON lgl.location_group_id = lg.id
        AND id_auth_location = NEW.id_auth_location 
SET 
    preferred_location_group_id = NULL;
end if;

end;

