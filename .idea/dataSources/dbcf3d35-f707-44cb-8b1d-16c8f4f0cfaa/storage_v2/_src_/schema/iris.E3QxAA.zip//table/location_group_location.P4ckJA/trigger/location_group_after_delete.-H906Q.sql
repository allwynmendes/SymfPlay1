create trigger location_group_after_delete
  after DELETE
  on location_group_location
  for each row
  begin 
update location_group lg set updated_on=unix_timestamp() where lg.id = OLD.location_group_id;
end;

