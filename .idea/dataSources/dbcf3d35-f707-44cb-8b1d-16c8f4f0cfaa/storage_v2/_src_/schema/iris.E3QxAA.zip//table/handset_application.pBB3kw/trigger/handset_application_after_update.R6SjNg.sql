create trigger handset_application_after_update
  after UPDATE
  on handset_application
  for each row
  BEGIN

                                INSERT INTO iris.handset_application_audit (
                                    audit_on,
                                    handset_application_id,
                                    handset_id,
                                    application_id,
                                    version_id)
                                VALUES (
                                    UNIX_TIMESTAMP(),
                                    NEW.id,
                                    NEW.handset_id,
                                    NEW.application_id,
                                    NEW.version_id);

                        END;

